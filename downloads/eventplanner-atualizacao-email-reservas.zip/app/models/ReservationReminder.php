<?php

/** One operational reminder per event, channel and contact. */
class ReservationReminder
{
    private $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
        $db->exec('CREATE TABLE IF NOT EXISTS reservation_reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            reservation_id INTEGER NOT NULL,
            channel TEXT NOT NULL,
            destination TEXT NOT NULL,
            status TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(event_id, channel, destination)
        )');
    }

    public function history(int $eventId): array
    {
        $stmt = $this->db->prepare('SELECT * FROM reservation_reminders WHERE event_id = ? ORDER BY id DESC');
        $stmt->execute([$eventId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function destination(array $row, string $channel): string
    {
        if ($channel === 'email') {
            $email = strtolower(trim((string)($row['customer_email'] ?? '')));
            return filter_var($email, FILTER_VALIDATE_EMAIL) ? $email : '';
        }
        $phone = preg_replace('/[\s().-]+/', '', trim((string)($row['customer_phone'] ?? '')));
        if (substr($phone, 0, 2) === '00') {
            $phone = '+' . substr($phone, 2);
        }
        if (preg_match('/^[29][0-9]{8}$/', $phone)) {
            $phone = '+351' . $phone;
        }
        return preg_match('/^\+[1-9][0-9]{7,14}$/', $phone) ? $phone : '';
    }

    public static function personalize(string $text, array $row): string
    {
        $date = (string)($row['event_date'] ?? '');
        if (preg_match('/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/', $date, $parts)) {
            $date = $parts[3] . '/' . $parts[2] . '/' . $parts[1];
        }
        return strtr($text, [
            '{customer_name}' => (string)($row['customer_name'] ?? ''),
            '{event_title}' => (string)($row['event_title'] ?? ''),
            '{event_date}' => $date,
            '{event_time}' => substr((string)($row['event_time'] ?? ''), 0, 5),
            '{event_location}' => (string)($row['event_location'] ?? ''),
            '{tickets}' => (string)($row['tickets'] ?? ''),
        ]);
    }

    public function recipients(array $reservations, string $channel, bool $confirmedOnly): array
    {
        $recipients = [];
        $seen = [];
        $ignored = 0;
        foreach ($reservations as $row) {
            if (!in_array($row['status'], ['new', 'confirmed'], true)
                || ($confirmedOnly && $row['status'] !== 'confirmed')) {
                continue;
            }
            $destination = self::destination($row, $channel);
            if ($destination === '' || isset($seen[$destination])) {
                $ignored++;
                continue;
            }
            $seen[$destination] = true;
            $recipients[] = ['reservation_id' => (int)$row['id'], 'destination' => $destination, 'row' => $row];
        }
        return ['recipients' => $recipients, 'ignored' => $ignored];
    }

    /** Atomic claim before contacting the provider: concurrent requests cannot duplicate a send. */
    public function claim(int $eventId, int $reservationId, string $channel, string $destination): bool
    {
        $stmt = $this->db->prepare("INSERT OR IGNORE INTO reservation_reminders (event_id, reservation_id, channel, destination, status) VALUES (?, ?, ?, ?, 'processing')");
        $stmt->execute([$eventId, $reservationId, $channel, $destination]);
        return $stmt->rowCount() === 1;
    }

    public function finish(int $eventId, string $channel, string $destination, string $status): void
    {
        $stmt = $this->db->prepare('UPDATE reservation_reminders SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE event_id = ? AND channel = ? AND destination = ?');
        $stmt->execute([$status, $eventId, $channel, $destination]);
    }
}
