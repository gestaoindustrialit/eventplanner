<?php

class ReservationReminderController extends BaseController
{
    public function index(): void
    {
        // Use the existing reservations permission, including for delegated staff.
        requireLogin();
        if (!can('reservation')) {
            http_response_code(403);
            echo 'Acesso negado.';
            return;
        }
        header('Cache-Control: private, no-store');
        $model = new ReservationReminder($this->db);
        $reservationModel = new Reservation($this->db);
        $events = $reservationModel->reservationEvents();
        $eventId = max(0, (int)($_POST['event_id'] ?? $_GET['event_id'] ?? 0));
        $channel = (string)($_POST['channel'] ?? 'email');
        if ($channel !== 'email') {
            $channel = 'email';
        }
        $scope = ($_POST['scope'] ?? 'active') === 'confirmed' ? 'confirmed' : 'active';
        $subject = trim((string)($_POST['subject'] ?? 'Lembrete: {event_title}'));
        $message = trim((string)($_POST['message'] ?? "Olá {customer_name}! Lembramos que {event_title} é no dia {event_date}, às {event_time}, em {event_location}. Até lá!"));
        $error = '';
        $preview = null;
        $result = null;
        if (empty($_SESSION['reminder_csrf'])) {
            $_SESSION['reminder_csrf'] = bin2hex(random_bytes(32));
        }
        $csrf = $_SESSION['reminder_csrf'];
        $history = $eventId > 0 ? $model->history($eventId) : [];
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
            if (!hash_equals($csrf, (string)($_POST['csrf'] ?? ''))) {
                http_response_code(403);
                $error = 'A sessão do formulário expirou. Volte a pré-visualizar.';
            } elseif (($_POST['step'] ?? '') === 'send') {
                $planToken = (string)($_POST['plan_token'] ?? '');
                $plan = $_SESSION['reminder_plans'][$planToken] ?? null;
                if (!$plan || $plan['expires'] < time()) {
                    $error = 'A pré-visualização expirou ou já foi utilizada. Prepare um novo envio.';
                } else {
                    // Consume before sending, even if the browser resubmits the request.
                    unset($_SESSION['reminder_plans'][$planToken]);
                    $eventId = $plan['event_id'];
                    $channel = $plan['channel'];
                    $subject = $plan['subject'];
                    $message = $plan['message'];
                    $scope = $plan['scope'];
                    $result = ['accepted' => 0, 'failed' => 0, 'skipped' => 0];
                    $current = [];
                    foreach ($reservationModel->all($eventId) as $row) {
                        $current[(int)$row['id']] = $row;
                    }
                    $batch = array_splice($plan['recipients'], 0, 20);
                    foreach ($batch as $recipient) {
                        $row = $current[$recipient['reservation_id']] ?? null;
                        if (!$row || !in_array($row['status'], ['new', 'confirmed'], true)
                            || ($scope === 'confirmed' && $row['status'] !== 'confirmed')
                            || ReservationReminder::destination($row, $channel) !== $recipient['destination']) {
                            $result['skipped']++;
                            continue;
                        }
                        if (!$model->claim($eventId, (int)$row['id'], $channel, $recipient['destination'])) {
                            $result['skipped']++;
                            continue;
                        }
                        $accepted = false;
                        try {
                            // Exactly one recipient per call, never CC/BCC.
                            $emailSubject = str_replace(["\r", "\n"], ' ', $recipient['subject']);
                            $accepted = mail($recipient['destination'], '=?UTF-8?B?' . base64_encode($emailSubject) . '?=', $recipient['body'], implode("\r\n", [
                                'MIME-Version: 1.0',
                                'Content-Type: text/plain; charset=UTF-8',
                                'From: noreply@chorarderir.com',
                            ]));
                        } catch (Throwable $e) {
                            // No provider or recipient details in public error messages.
                        }
                        $model->finish($eventId, $channel, $recipient['destination'], $accepted ? 'accepted' : 'failed');
                        $result[$accepted ? 'accepted' : 'failed']++;
                    }
                    if ($plan['recipients']) {
                        $preview = $this->storePlan($plan);
                    }
                    $history = $model->history($eventId);
                }
            } else {
                $validEvent = false;
                foreach ($events as $event) {
                    if ((int)$event['id'] === $eventId) {
                        $validEvent = true;
                    }
                }
                if (!$validEvent) {
                    $error = 'Selecione um evento com reservas.';

                } elseif ($message === '' || $subject === '' || strlen($message) > 10000 || strlen($subject) > 500) {
                    $error = 'Preencha o assunto (até 500 bytes) e a mensagem (até 10 000 bytes).';
                } else {
                    $selection = $model->recipients($reservationModel->all($eventId), $channel, $scope === 'confirmed');
                    $attempted = [];
                    foreach ($history as $entry) {
                        if ($entry['channel'] === $channel) {
                            $attempted[$entry['destination']] = true;
                        }
                    }
                    $recipients = [];
                    foreach ($selection['recipients'] as $recipient) {
                        if (isset($attempted[$recipient['destination']])) {
                            $selection['ignored']++;
                            continue;
                        }
                        $recipient['subject'] = ReservationReminder::personalize($subject, $recipient['row']);
                        $recipient['body'] = ReservationReminder::personalize($message, $recipient['row']);
                        $recipient['name'] = $recipient['row']['customer_name'];
                        unset($recipient['row']);
                        $recipients[] = $recipient;
                    }
                    if (!$recipients) {
                        $error = 'Sem destinatários elegíveis por contactar neste evento e canal.';
                    } else {
                        $preview = $this->storePlan([
                            'event_id' => $eventId, 'channel' => $channel, 'subject' => $subject,
                            'message' => $message, 'scope' => $scope, 'recipients' => $recipients,
                            'ignored' => $selection['ignored'], 'expires' => time() + 1800,
                        ]);
                    }
                }
            }
        }
        $this->render('reservations/reminders', compact('events', 'eventId', 'channel', 'scope', 'subject', 'message', 'csrf', 'error', 'preview', 'result', 'history'));
    }

    private function storePlan(array $plan): array
    {
        $plans = $_SESSION['reminder_plans'] ?? [];
        foreach ($plans as $key => $existing) {
            if ($existing['expires'] < time()) {
                unset($plans[$key]);
            }
        }
        while (count($plans) >= 5) {
            array_shift($plans);
        }
        $token = bin2hex(random_bytes(24));
        $plans[$token] = $plan;
        $_SESSION['reminder_plans'] = $plans;
        $plan['token'] = $token;
        return $plan;
    }
}
