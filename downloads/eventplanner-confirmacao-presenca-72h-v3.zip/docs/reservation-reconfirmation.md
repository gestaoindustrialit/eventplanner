# Confirmação de presença 72 horas antes do evento

Esta atualização acrescenta um fluxo manual de pedido de confirmação. Mantém os lembretes simples, o CAPTCHA v2/v3, o antispam, as ações múltiplas, os bilhetes e as mensagens em destaque.

## Utilização

1. Instale os ficheiros mantendo os caminhos relativos à raiz do Eventplanner. Não execute `install.php` e não substitua a base de dados. A nova tabela `reservation_reconfirmations` é criada de forma idempotente.
2. Em **Publicar website**, confirme as definições CAPTCHA existentes e publique novamente. Além de preservar os handlers protegidos, a publicação gera `confirmar-reserva.php` no site público. A página é independente do login administrativo.
3. Abra **Reservas → Gerir confirmações de presença**. Selecione o evento. O painel mostra a hora de abertura do envio, exatamente 72 horas antes do início, calculada em Europe/Lisbon.
4. Escolha explicitamente o prazo para responder: até 24 horas antes do evento, durante 24 horas após cada envio (limitado ao início do evento), ou até ao início do evento. Não existe prazo selecionado por omissão. O prazo exato aparece na pré-visualização e na mensagem. Uma escolha cujo prazo já terminou não permite enviar.
5. Confirme a URL HTTPS da página publicada (por exemplo `https://chorarderir.com/confirmar-reserva.php`) e reveja os destinatários. Só são incluídas reservas **Novas**, com e-mail válido e bilhetes ainda não utilizados. Reservas já **Confirmadas** não precisam de reconfirmar neste fluxo. Cada reserva recebe a sua própria ligação, mesmo que várias partilhem um e-mail.
6. Envie em lotes de até 20. Após cada lote, continue até terminar. Este botão envia o pedido real; a pré-visualização não envia mensagens. `mail()` do alojamento e o remetente `noreply@chorarderir.com` devem funcionar. Aceite pelo servidor não comprova entrega na caixa de entrada.
7. A pessoa abre a ligação e carrega em **Confirmar a minha reserva**. Apenas o POST desse botão, com sessão e CSRF válidos, altera a reserva para **Confirmada**. Abrir a ligação ou um analisador de segurança abrir o e-mail não confirma nem cancela nada.
8. Depois do prazo, carregue em **Rever reservas com prazo terminado**, reveja as reservas listadas e confirme o cancelamento. O cancelamento muda o estado para **Cancelada**, liberta a lotação e mantém os registos/bilhetes para consulta. A admissão continua a rejeitar bilhetes de reservas canceladas.

Não existe cron, envio automático agendado nem cancelamento automático em segundo plano. É necessário abrir o painel para enviar e, depois do prazo, rever e libertar as reservas sem resposta. Isto permite iniciar o envio quando entra na janela das 72 horas e controlar a perda da reserva manualmente.

## Proteções e limites

- Pedidos de confirmação separados dos lembretes normais; enviar um lembrete nunca torna uma reserva elegível para cancelamento por falta de resposta.
- Ligações pessoais com 32 bytes aleatórios; a base de dados guarda apenas SHA-256, nunca o token original. Não são usados IDs previsíveis nem o token do QR do bilhete para confirmar presença.
- HTTPS obrigatório na URL configurada pelo operador, sem usar o cabeçalho Host recebido para gerar e-mails. A página não carrega scripts, trackers ou recursos externos; inclui CSP, bloqueio de frames, `no-referrer`, `noindex` e `no-store`, sessão própria e cookies HttpOnly/SameSite.
- O GET é só de leitura da reserva. POST com CSRF é obrigatório. Token expirado, inválido, cancelado, consumido e posteriormente reaberto pelo operador, ou associado a e-mail, bilhetes ou horário alterados não pode confirmar uma reserva.
- A confirmação e o cancelamento usam transações SQLite com bloqueio de escrita e revalidação do estado. Confirmações repetidas são idempotentes. Uma resposta nunca altera outras reservas.
- A pré-visualização fica guardada na sessão administrativa por 30 minutos (10 para libertação), com nonce de utilização única. Evento, destinatários, URL e prazo usados no envio vêm desse plano e são revalidados no servidor. Lotes são limitados a 20.
- Só os pedidos aceites pelo servidor de correio, sem confirmação e efetivamente vencidos podem ser cancelados. Falhas explícitas podem ser repetidas por opção do operador, invalidando o token anterior. Resultado incerto/interrompido fica em processamento: sem repetição nem cancelamento automático.
- Reservas alteradas depois do pedido, confirmadas entretanto, canceladas, removidas ou com bilhetes utilizados ficam protegidas de cancelamento neste fluxo. Se alterar o e-mail, o número de bilhetes ou o horário após o envio, reveja a reserva manualmente; as ligações anteriores deixam de servir.
- O histórico conserva o utilizador e instante do pedido, resultado do envio, prazo, resposta e utilizador/instante do cancelamento manual. Não é publicada uma lista de clientes na página pública.
- A ligação funciona como credencial: quem a receber pode confirmar essa reserva. Não a partilhe. Os registos HTTP do alojamento podem incluir a query do primeiro acesso; configure o alojamento para omitir/ocultar o parâmetro `token` nos logs e manter o acesso a logs restrito.

## Validação

Testes automatizados cobrem os prazos e fuso horário, exclusão de reservas confirmadas/canceladas, token aleatório e apenas hash persistido, rejeição de tokens antigos, reenvio controlado de falhas, falhas incertas, revalidação de alterações, cancelamento manual restrito às reservas revistas, CSRF, método HTTP e cabeçalhos. O fluxo HTTP da página exportada foi testado num servidor local. Chromium verificou computador/telemóvel, botão explícito, resultado e acesso à página administrativa. Os testes anteriores de antispam, CAPTCHA, ações múltiplas e lembretes também passam. Nenhum e-mail real foi enviado e nenhum dado de produção foi alterado.
