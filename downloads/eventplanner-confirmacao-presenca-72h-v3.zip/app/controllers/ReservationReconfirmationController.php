<?php

class ReservationReconfirmationController extends BaseController
{
    public function index(): void
    {
        requireLogin();
        if (!can('reservation')) {
            http_response_code(403);
            echo 'Acesso negado.';
            return;
        }
        header('Cache-Control: private, no-store');
        header('X-Robots-Tag: noindex, nofollow');
        $model = new ReservationReconfirmation($this->db);
        $events = (new Reservation($this->db))->reservationEvents();
        $settings = new SiteSetting($this->db);
        $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $eventId = max(0, (int)($method === 'POST' ? $this->post('event_id') : (is_string($_GET['event_id'] ?? null) ? $_GET['event_id'] : '0')));
        $policy = $this->post('policy');
        $baseUrl = $this->post('base_url', $settings->get('reservation_confirmation_base_url', 'https://chorarderir.com/confirmar-reserva.php') ?? '');
        $retryFailed = $this->post('retry_failed') === '1';
        $error = '';
        $notice = '';
        $plan = null;
        if (empty($_SESSION['reconfirmation_admin_csrf'])) {
            $_SESSION['reconfirmation_admin_csrf'] = bin2hex(random_bytes(32));
        }
        $csrf = $_SESSION['reconfirmation_admin_csrf'];
        if (!in_array($method, ['GET', 'POST'], true)) {
            http_response_code(405);
            header('Allow: GET, POST');
            return;
        }
        if ($method === 'POST') {
            if (!hash_equals($csrf, $this->post('csrf'))) {
                http_response_code(403);
                $error = 'A sessão do formulário expirou. Atualize a página.';
            } else {
                try {
                    $step = $this->post('step');
                    if ($step === 'preview') {
                        if (!ReservationReconfirmation::validBaseUrl($baseUrl) || $this->post('page_published') !== '1') {
                            throw new InvalidArgumentException('Confirme a publicação da página e indique a sua URL HTTPS, terminada em /confirmar-reserva.php.');
                        }
                        $selection = $model->preview($eventId, $policy, $retryFailed, time());
                        if (!$selection['recipients']) {
                            throw new InvalidArgumentException('Não existem reservas novas elegíveis. As confirmadas, canceladas, sem e-mail válido ou já contactadas são excluídas.');
                        }
                        $settings->set('reservation_confirmation_base_url', $baseUrl);
                        $plan = $this->storePlan(array_merge($selection, ['type' => 'send', 'base_url' => $baseUrl, 'policy' => $policy, 'expires' => time() + 1800]));
                    } elseif ($step === 'preview_expire') {
                        $candidates = $model->expiredCandidates($eventId, time());
                        if (!$candidates) {
                            throw new InvalidArgumentException('Não existem pedidos enviados, sem resposta e com prazo terminado para libertar neste evento.');
                        }
                        $plan = $this->storePlan(['type' => 'expire', 'event' => $model->event($eventId), 'recipients' => $candidates, 'expires' => time() + 600]);
                    } elseif (in_array($step, ['send', 'expire'], true)) {
                        $token = $this->post('plan_token');
                        $stored = $_SESSION['reconfirmation_plans'][$token] ?? null;
                        if (!$stored || $stored['expires'] <= time() || $stored['type'] !== $step) {
                            throw new InvalidArgumentException('A pré-visualização expirou ou já foi utilizada. Prepare novamente.');
                        }
                        unset($_SESSION['reconfirmation_plans'][$token]);
                        $eventId = (int)$stored['event']['id'];
                        if ($step === 'expire') {
                            $count = $model->expire($eventId, array_column($stored['recipients'], 'request_id'), time(), (int)(currentUser()['id'] ?? 0));
                            $notice = $count . ' reserva(s) sem resposta cancelada(s); lugares libertados. As reservas que entretanto foram confirmadas mantêm-se.';
                        } else {
                            $baseUrl = $stored['base_url'];
                            $policy = $stored['policy'];
                            $accepted = 0;
                            $failed = 0;
                            $skipped = 0;
                            $batch = array_splice($stored['recipients'], 0, 20);
                            foreach ($batch as $recipient) {
                                $issued = $model->issue($stored, $recipient, (int)(currentUser()['id'] ?? 0), time());
                                if (!$issued) {
                                    $skipped++;
                                    continue;
                                }
                                $url = $baseUrl . '?token=' . rawurlencode($issued['token']);
                                $body = $this->emailBody(array_merge($stored, ['deadline' => $issued['deadline']]), $recipient, $url);
                                $title = str_replace(["\r", "\n"], ' ', 'Confirma a tua reserva — ' . $stored['event']['title']);
                                $ok = false;
                                try {
                                    $ok = $this->deliver($recipient['email'], $title, $body);
                                } catch (Throwable $e) {
                                    // Unknown mail outcome: retain processing; never expire or retry automatically.
                                    $skipped++;
                                    continue;
                                }
                                $model->markSent($issued['hash'], $ok);
                                if ($ok) { $accepted++; } else { $failed++; }
                            }
                            $notice = $accepted . ' e-mail(s) aceite(s) pelo servidor; ' . $failed . ' falha(s); ' . $skipped . ' ignorado(s) ou com resultado por confirmar. A aceitação não comprova a entrega.';
                            if ($stored['recipients']) {
                                $plan = $this->storePlan($stored);
                            }
                        }
                    } else {
                        throw new InvalidArgumentException('Ação inválida.');
                    }
                } catch (InvalidArgumentException $e) {
                    $error = $e->getMessage();
                } catch (Throwable $e) {
                    $error = 'Não foi possível concluir a operação. Consulte o histórico antes de tentar novamente.';
                }
            }
        }
        $event = $eventId > 0 ? $model->event($eventId) : null;
        $history = $eventId > 0 ? $model->history($eventId) : [];
        $this->render('reservations/reconfirmation', compact('events', 'eventId', 'event', 'policy', 'baseUrl', 'retryFailed', 'csrf', 'error', 'notice', 'plan', 'history'));
    }

    protected function deliver(string $email, string $subject, string $body): bool
    {
        return mail($email, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, implode("\r\n", [
            'MIME-Version: 1.0', 'Content-Type: text/plain; charset=UTF-8', 'From: noreply@chorarderir.com',
        ]));
    }

    private function emailBody(array $plan, array $recipient, string $url): string
    {
        return 'Olá ' . $recipient['name'] . ",\n\n"
            . 'A tua reserva para ' . $plan['event']['title'] . ' (' . $recipient['tickets'] . ' bilhete(s)) aguarda confirmação de presença.' . "\n"
            . 'Evento: ' . ReservationReconfirmation::displayTime((int)$plan['event_start']) . ' — ' . $plan['event']['location'] . "\n\n"
            . 'Confirma até ' . ReservationReconfirmation::displayTime((int)$plan['deadline']) . ' (hora de Portugal continental).' . "\n"
            . 'Sem confirmação dentro do prazo, a reserva será cancelada e os lugares poderão ser atribuídos a outras pessoas.' . "\n\n"
            . 'Abre esta ligação e carrega em «Confirmar a minha reserva»:' . "\n" . $url . "\n\n"
            . 'Esta ligação é pessoal e confirma apenas esta reserva. Não a partilhes. Se já não puderes comparecer, contacta a organização.';
    }

    private function post(string $key, string $default = ''): string
    {
        return isset($_POST[$key]) && is_string($_POST[$key]) ? trim($_POST[$key]) : $default;
    }

    private function storePlan(array $plan): array
    {
        $plans = $_SESSION['reconfirmation_plans'] ?? [];
        foreach ($plans as $token => $value) {
            if ($value['expires'] <= time()) { unset($plans[$token]); }
        }
        while (count($plans) >= 5) { array_shift($plans); }
        $token = bin2hex(random_bytes(24));
        $plans[$token] = $plan;
        $_SESSION['reconfirmation_plans'] = $plans;
        $plan['token'] = $token;
        return $plan;
    }
}
