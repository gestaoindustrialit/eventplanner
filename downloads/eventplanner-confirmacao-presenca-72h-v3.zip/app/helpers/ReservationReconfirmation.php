<?php

/** Separate from ordinary reminders. All public writes are explicit, atomic confirmations. */
class ReservationReconfirmation
{
    private $db;

    public function __construct(PDO $db)
    {
        $this->db = $db;
        $db->exec('PRAGMA busy_timeout = 5000');
        $db->exec('CREATE TABLE IF NOT EXISTS reservation_reconfirmations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            reservation_id INTEGER NOT NULL UNIQUE,
            event_id INTEGER NOT NULL,
            token_hash TEXT NOT NULL UNIQUE,
            email_snapshot TEXT NOT NULL,
            tickets_snapshot INTEGER NOT NULL,
            event_start INTEGER NOT NULL,
            deadline INTEGER NOT NULL,
            requested_at INTEGER NOT NULL,
            requested_by INTEGER NOT NULL,
            send_state TEXT NOT NULL,
            confirmed_at INTEGER DEFAULT NULL,
            expired_at INTEGER DEFAULT NULL,
            expired_by INTEGER DEFAULT NULL
        )');
        $columns = array_column($db->query('PRAGMA table_info(reservation_reconfirmations)')->fetchAll(PDO::FETCH_ASSOC), 'name');
        if (!in_array('expired_by', $columns, true)) {
            $db->exec('ALTER TABLE reservation_reconfirmations ADD COLUMN expired_by INTEGER DEFAULT NULL');
        }
        $db->exec('CREATE INDEX IF NOT EXISTS reservation_reconfirmation_event ON reservation_reconfirmations (event_id, deadline)');
    }

    public static function eventStart(array $event): int
    {
        $value = (string)($event['date'] ?? '') . ' ' . substr((string)($event['time'] ?? ''), 0, 5);
        $date = DateTimeImmutable::createFromFormat('!Y-m-d H:i', $value, new DateTimeZone('Europe/Lisbon'));
        if (!$date || $date->format('Y-m-d H:i') !== $value) {
            throw new InvalidArgumentException('Data/hora do evento inválida.');
        }
        return $date->getTimestamp();
    }

    public static function displayTime(int $timestamp): string
    {
        return (new DateTimeImmutable('@' . $timestamp))->setTimezone(new DateTimeZone('Europe/Lisbon'))->format('d/m/Y H:i');
    }

    public static function deadline(int $start, string $policy, int $now): int
    {
        $policies = ['before24' => $start - 86400, 'after24' => min($now + 86400, $start), 'event' => $start];
        if (!isset($policies[$policy])) {
            throw new InvalidArgumentException('Escolha o prazo de confirmação.');
        }
        return $policies[$policy];
    }

    public static function validBaseUrl(string $url): bool
    {
        $parts = parse_url($url);
        return strlen($url) <= 500 && filter_var($url, FILTER_VALIDATE_URL) !== false
            && is_array($parts) && ($parts['scheme'] ?? '') === 'https'
            && !isset($parts['user']) && !isset($parts['pass']) && !isset($parts['query']) && !isset($parts['fragment'])
            && substr($parts['path'] ?? '', -strlen('/confirmar-reserva.php')) === '/confirmar-reserva.php';
    }

    public function event(int $eventId): ?array
    {
        $stmt = $this->db->prepare('SELECT id, title, date, time, location FROM events WHERE id = ?');
        $stmt->execute([$eventId]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private function reservation(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT r.*, e.title AS event_title, e.date, e.time, e.location FROM event_reservations r JOIN events e ON e.id = r.event_id WHERE r.id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private function requestFor(int $id): ?array
    {
        $stmt = $this->db->prepare('SELECT * FROM reservation_reconfirmations WHERE reservation_id = ?');
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    private function matches(array $request, array $row): bool
    {
        return (int)$request['event_id'] === (int)$row['event_id']
            && (int)$request['event_start'] === self::eventStart($row)
            && $request['email_snapshot'] === strtolower(trim((string)$row['customer_email']))
            && (int)$request['tickets_snapshot'] === (int)$row['tickets'];
    }

    private function usedTickets(int $reservationId): bool
    {
        $stmt = $this->db->prepare('SELECT 1 FROM event_reservation_tickets WHERE reservation_id = ? AND is_used = 1 LIMIT 1');
        $stmt->execute([$reservationId]);
        return (bool)$stmt->fetchColumn();
    }

    public function preview(int $eventId, string $policy, bool $retryFailed, int $now): array
    {
        $event = $this->event($eventId);
        if (!$event) {
            throw new InvalidArgumentException('Selecione um evento.');
        }
        $start = self::eventStart($event);
        $deadline = self::deadline($start, $policy, $now);
        if ($now < $start - 72 * 3600 || $now >= $deadline) {
            throw new InvalidArgumentException('O envio manual abre 72 horas antes do evento e termina antes do prazo escolhido.');
        }
        $stmt = $this->db->prepare("SELECT r.*, q.send_state, q.confirmed_at, q.expired_at FROM event_reservations r LEFT JOIN reservation_reconfirmations q ON q.reservation_id = r.id WHERE r.event_id = ? AND r.status = 'new' ORDER BY r.id");
        $stmt->execute([$eventId]);
        $recipients = [];
        $ignored = 0;
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $email = strtolower(trim((string)$row['customer_email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $this->usedTickets((int)$row['id'])
                || ($row['send_state'] !== null && !($retryFailed && $row['send_state'] === 'failed' && $row['confirmed_at'] === null && $row['expired_at'] === null))) {
                $ignored++;
                continue;
            }
            // Each reservation must be confirmed independently, even with the same e-mail.
            $recipients[] = ['id' => (int)$row['id'], 'name' => $row['customer_name'], 'email' => $email, 'tickets' => (int)$row['tickets']];
        }
        return ['event' => $event, 'event_start' => $start, 'deadline' => $deadline, 'recipients' => $recipients, 'ignored' => $ignored, 'retry_failed' => $retryFailed];
    }

    /** Returns the raw token only to the mail sender; never persists it. */
    public function issue(array $plan, array $recipient, int $actor, int $now): ?array
    {
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $row = $this->reservation((int)$recipient['id']);
            $existing = $this->requestFor((int)$recipient['id']);
            if (!$row || $row['status'] !== 'new' || (int)$row['event_id'] !== (int)$plan['event']['id']
                || self::eventStart($row) !== (int)$plan['event_start']
                || (int)$row['tickets'] !== (int)$recipient['tickets']
                || strtolower(trim((string)$row['customer_email'])) !== $recipient['email']
                || !filter_var($recipient['email'], FILTER_VALIDATE_EMAIL)
                || $this->usedTickets((int)$row['id']) || $now < $plan['event_start'] - 72 * 3600
                || $now >= $plan['deadline'] || $plan['deadline'] > $plan['event_start']
                || ($existing && !($plan['retry_failed'] && $existing['send_state'] === 'failed' && $existing['confirmed_at'] === null && $existing['expired_at'] === null))) {
                $this->db->exec('COMMIT');
                return null;
            }
            $token = bin2hex(random_bytes(32));
            $deadline = ($plan['policy'] ?? '') === 'after24' ? min($now + 86400, (int)$plan['event_start']) : (int)$plan['deadline'];
            $values = [hash('sha256', $token), $recipient['email'], $recipient['tickets'], $plan['event_start'], $deadline, $now, $actor, (int)$row['event_id'], (int)$row['id']];
            if ($existing) {
                $sql = "UPDATE reservation_reconfirmations SET token_hash=?, email_snapshot=?, tickets_snapshot=?, event_start=?, deadline=?, requested_at=?, requested_by=?, event_id=?, send_state='processing' WHERE reservation_id=?";
            } else {
                $sql = "INSERT INTO reservation_reconfirmations (token_hash,email_snapshot,tickets_snapshot,event_start,deadline,requested_at,requested_by,event_id,reservation_id,send_state) VALUES (?,?,?,?,?,?,?,?,?,'processing')";
            }
            $this->db->prepare($sql)->execute($values);
            $this->db->exec('COMMIT');
            return ['token' => $token, 'hash' => hash('sha256', $token), 'reservation' => $row, 'deadline' => $deadline];
        } catch (Throwable $e) {
            $this->db->exec('ROLLBACK');
            throw $e;
        }
    }

    public function markSent(string $hash, bool $accepted): void
    {
        $stmt = $this->db->prepare("UPDATE reservation_reconfirmations SET send_state=? WHERE token_hash=? AND send_state='processing'");
        $stmt->execute([$accepted ? 'accepted' : 'failed', $hash]);
    }

    public function inspect(string $token, int $now): array
    {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) {
            return ['state' => 'invalid'];
        }
        $stmt = $this->db->prepare('SELECT * FROM reservation_reconfirmations WHERE token_hash = ? LIMIT 1');
        $stmt->execute([hash('sha256', $token)]);
        $request = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$request || $request['send_state'] !== 'accepted') {
            return ['state' => 'invalid'];
        }
        $row = $this->reservation((int)$request['reservation_id']);
        if (!$row || !$this->matches($request, $row) || $row['status'] === 'cancelled' || $request['expired_at'] !== null) {
            return ['state' => 'invalid'];
        }
        if ($request['confirmed_at'] !== null && $row['status'] !== 'confirmed') {
            return ['state' => 'invalid'];
        }
        if ($row['status'] === 'confirmed') {
            return ['state' => 'confirmed'];
        }
        if ($row['status'] !== 'new' || $now >= (int)$request['deadline']) {
            return ['state' => 'expired'];
        }
        return ['state' => 'pending', 'request' => $request, 'event_title' => $row['event_title'], 'location' => $row['location'], 'tickets' => (int)$row['tickets']];
    }

    /** GET/inspect never confirm or cancel. Caller must verify browser CSRF before this method. */
    public function confirm(string $token, int $now): string
    {
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $data = $this->inspect($token, $now);
            if ($data['state'] === 'pending') {
                $request = $data['request'];
                $stmt = $this->db->prepare("UPDATE event_reservations SET status='confirmed' WHERE id=? AND event_id=? AND status='new'");
                $stmt->execute([$request['reservation_id'], $request['event_id']]);
                if ($stmt->rowCount() !== 1) {
                    throw new RuntimeException('Reservation changed.');
                }
                $this->db->prepare('UPDATE reservation_reconfirmations SET confirmed_at=? WHERE id=? AND confirmed_at IS NULL')->execute([$now, $request['id']]);
                $data['state'] = 'confirmed';
            }
            $this->db->exec('COMMIT');
            return $data['state'];
        } catch (Throwable $e) {
            $this->db->exec('ROLLBACK');
            throw $e;
        }
    }

    public function expiredCandidates(int $eventId, int $now): array
    {
        $stmt = $this->db->prepare("SELECT * FROM reservation_reconfirmations WHERE event_id=? AND send_state='accepted' AND deadline<=? AND confirmed_at IS NULL AND expired_at IS NULL ORDER BY id");
        $stmt->execute([$eventId, $now]);
        $result = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $request) {
            $row = $this->reservation((int)$request['reservation_id']);
            if ($row && $row['status'] === 'new' && $this->matches($request, $row) && !$this->usedTickets((int)$row['id'])) {
                $result[] = ['request_id' => (int)$request['id'], 'id' => (int)$row['id'], 'name' => $row['customer_name'], 'email' => $row['customer_email'], 'tickets' => (int)$row['tickets']];
            }
        }
        return $result;
    }

    /** Manual release touches only the IDs reviewed by staff and rechecks everything under lock. */
    public function expire(int $eventId, array $reviewedIds, int $now, int $actor = 0): int
    {
        $this->db->exec('BEGIN IMMEDIATE');
        try {
            $count = 0;
            foreach ($this->expiredCandidates($eventId, $now) as $candidate) {
                if (!in_array($candidate['request_id'], $reviewedIds, true)) {
                    continue;
                }
                $this->db->prepare("UPDATE event_reservations SET status='cancelled' WHERE id=? AND status='new'")->execute([$candidate['id']]);
                $this->db->prepare('UPDATE reservation_reconfirmations SET expired_at=?, expired_by=? WHERE id=?')->execute([$now, $actor, $candidate['request_id']]);
                $count++;
            }
            $this->db->exec('COMMIT');
            return $count;
        } catch (Throwable $e) {
            $this->db->exec('ROLLBACK');
            throw $e;
        }
    }

    public function history(int $eventId): array
    {
        $stmt = $this->db->prepare('SELECT q.*, r.customer_name, r.status AS reservation_status FROM reservation_reconfirmations q LEFT JOIN event_reservations r ON r.id=q.reservation_id WHERE q.event_id=? ORDER BY q.id DESC');
        $stmt->execute([$eventId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
