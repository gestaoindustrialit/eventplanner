<?php

/** Public entry point shared by the export and isolated tests; no admin authentication. */
function reservation_confirmation_page(string $dbPath): void
{
    header('Cache-Control: private, no-store, max-age=0');
    header('Pragma: no-cache');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Referrer-Policy: no-referrer');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");
    header('Content-Type: text/html; charset=UTF-8');
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    if (!in_array($method, ['GET', 'POST'], true)) {
        http_response_code(405);
        header('Allow: GET, POST');
        echo 'Método não permitido.';
        return;
    }
    $input = $method === 'POST' ? $_POST : $_GET;
    $token = isset($input['token']) && is_string($input['token']) ? $input['token'] : '';
    $state = 'invalid';
    $data = [];
    $csrf = '';
    try {
        if (preg_match('/^[a-f0-9]{64}$/D', $token)) {
            if (session_status() !== PHP_SESSION_ACTIVE) {
                session_name('cdr_reconfirmation');
                session_cache_limiter('');
                session_set_cookie_params(['path' => '/', 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'httponly' => true, 'samesite' => 'Lax']);
                if (!session_start(['use_strict_mode' => true])) {
                    throw new RuntimeException('Session unavailable.');
                }
            }
            if (empty($_SESSION['reconfirmation_csrf'])) {
                $_SESSION['reconfirmation_csrf'] = bin2hex(random_bytes(32));
            }
            $csrf = $_SESSION['reconfirmation_csrf'];
            $validPost = $method === 'POST'
                && isset($_POST['csrf']) && is_string($_POST['csrf']) && hash_equals($csrf, $_POST['csrf'])
                && ($_POST['intent'] ?? '') === 'confirm';
            session_write_close();
            if ($method === 'POST' && !$validPost) {
                http_response_code(403);
                $state = 'csrf';
            } else {
                // Do not create an empty SQLite database if deployment points at a wrong path.
                if (!is_file($dbPath)) {
                    throw new RuntimeException('Database unavailable.');
                }
                $db = new PDO('sqlite:' . $dbPath, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC]);
                $model = new ReservationReconfirmation($db);
                if ($validPost) {
                    $state = $model->confirm($token, time());
                } else {
                    // Opening a link, including by an e-mail scanner, never confirms/cancels.
                    $data = $model->inspect($token, time());
                    $state = $data['state'];
                }
            }
        }
    } catch (Throwable $e) {
        http_response_code(503);
        $state = 'unavailable';
    }
    $messages = [
        'invalid' => ['Ligação indisponível', 'Esta ligação não é válida ou a reserva foi alterada ou cancelada. Contacta a organização.'],
        'expired' => ['Prazo de confirmação terminado', 'Já não é possível confirmar por esta ligação. Contacta a organização para verificar a disponibilidade.'],
        'confirmed' => ['Reserva confirmada!', 'A tua presença ficou confirmada. Guarda o e-mail com os bilhetes e apresenta-os no evento.'],
        'pending' => ['Confirma a tua reserva', 'Para manter a reserva, confirma a tua presença no botão abaixo.'],
        'csrf' => ['Sessão expirada', 'Abre novamente a ligação recebida no e-mail e volta a confirmar.'],
        'unavailable' => ['Serviço temporariamente indisponível', 'Não foi possível concluir a operação. Tenta novamente dentro de alguns minutos.'],
    ];
    $copy = $messages[$state] ?? $messages['invalid'];
    $esc = function ($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); };
    ?>
<!doctype html><html lang="pt-PT"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex,nofollow"><title><?= $esc($copy[0]) ?></title>
<style>body{margin:0;background:#f3f4f6;color:#172033;font:18px/1.6 system-ui,sans-serif;min-height:100vh;display:grid;place-items:center}main{box-sizing:border-box;background:white;border:1px solid #d8dee8;border-radius:18px;padding:32px;width:min(94%,600px);margin:24px}h1{font-size:30px;line-height:1.2}button{font:inherit;font-weight:700;padding:16px 24px;background:#155738;color:#fff;border:0;border-radius:10px;cursor:pointer;width:100%}button:focus-visible{outline:3px solid #e6a800;outline-offset:4px}.details{padding:16px;background:#f3f4f6;border-radius:10px}small{color:#475569}p{overflow-wrap:anywhere}</style></head><body><main role="main">
<small>CHORAR DE RIR · RESERVAS</small><h1><?= $esc($copy[0]) ?></h1><p role="status"><?= $esc($copy[1]) ?></p>
<?php if ($state === 'pending'): ?>
<div class="details"><strong><?= $esc($data['event_title']) ?></strong><br><?= $esc(ReservationReconfirmation::displayTime((int)$data['request']['event_start'])) ?> (Portugal continental)<br><?= $esc($data['location']) ?><br>Bilhetes: <?= (int)$data['tickets'] ?></div>
<p><strong>Confirma até <?= $esc(ReservationReconfirmation::displayTime((int)$data['request']['deadline'])) ?> (Portugal continental).</strong> Sem confirmação dentro do prazo, a reserva poderá ser cancelada e os lugares libertados.</p>
<form method="post" action="confirmar-reserva.php"><input type="hidden" name="token" value="<?= $esc($token) ?>"><input type="hidden" name="csrf" value="<?= $esc($csrf) ?>"><input type="hidden" name="intent" value="confirm"><button type="submit">Confirmar a minha reserva</button></form>
<?php endif; ?>
</main></body></html>
<?php
}
