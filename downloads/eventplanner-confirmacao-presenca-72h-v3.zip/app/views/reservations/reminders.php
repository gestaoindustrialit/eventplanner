<?php $esc = function ($value) { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }; ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-4">
    <h2 class="mb-0">Lembretes por e-mail</h2>
    <a class="btn btn-outline-secondary" href="<?= BASE_URL ?>?controller=reservation&amp;action=index&amp;event_id=<?= (int)$eventId ?>">Voltar às reservas</a>
</div>
<p class="text-muted">Cada pessoa recebe uma mensagem individual. Contactos repetidos e reservas canceladas são excluídos.</p>
<div class="position-fixed top-0 start-50 translate-middle-x p-3" style="z-index:2000;width:min(100%,720px);max-height:100vh;overflow:auto">
<?php if ($error): ?><div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button><?= $esc($error) ?></div><?php endif; ?>
<?php if ($result): ?>
<div class="alert alert-info alert-dismissible" role="status"><button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    <?= (int)$result['accepted'] ?> e-mail(s) aceite(s) pelo servidor de correio;
    <?= (int)$result['failed'] ?> falha(s); <?= (int)$result['skipped'] ?> ignorado(s).
    A aceitação pelo servidor não garante a entrega na caixa de entrada.
</div>
<?php endif; ?>
</div>
<div class="card shadow-sm mb-4"><div class="card-body">
<form method="post" action="<?= BASE_URL ?>?controller=reservation&amp;action=reminders" class="row g-3">
    <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>">
    <input type="hidden" name="step" value="preview">
    <div class="col-md-6"><label for="reminder-event" class="form-label">Evento</label>
        <select id="reminder-event" name="event_id" class="form-select" required>
            <option value="">Selecionar evento</option>
            <?php foreach ($events as $event): ?><option value="<?= (int)$event['id'] ?>" <?= (int)$event['id'] === $eventId ? 'selected' : '' ?>><?= $esc($event['title'] . ' — ' . $event['date'] . ' ' . substr($event['time'], 0, 5)) ?></option><?php endforeach; ?>
        </select>
    </div>
    <div class="col-md-3"><label for="reminder-channel" class="form-label">Enviar por</label>
        <input type="hidden" name="channel" value="email">
        <input id="reminder-channel" class="form-control" value="E-mail" readonly>
    </div>
    <div class="col-md-3"><label for="reminder-scope" class="form-label">Destinatários</label>
        <select id="reminder-scope" name="scope" class="form-select">
            <option value="active" <?= $scope === 'active' ? 'selected' : '' ?>>Todas as reservas ativas</option>
            <option value="confirmed" <?= $scope === 'confirmed' ? 'selected' : '' ?>>Apenas confirmadas</option>
        </select>
    </div>
    <div class="col-12"><label for="reminder-subject" class="form-label">Assunto do e-mail</label><input id="reminder-subject" name="subject" class="form-control" maxlength="500" value="<?= $esc($subject) ?>" required></div>
    <div class="col-12"><label for="reminder-message" class="form-label">Mensagem</label><textarea id="reminder-message" name="message" class="form-control" rows="5" maxlength="10000" required><?= $esc($message) ?></textarea>
        <div class="form-text">Personalização: {customer_name}, {event_title}, {event_date}, {event_time}, {event_location}, {tickets}.</div>
    </div>
    <div class="col-12"><button class="btn btn-dark">Pré-visualizar destinatários e mensagem</button></div>
</form>
</div></div>
<?php if ($preview): ?>
<div class="card border-dark mb-4"><div class="card-body">
    <h4>Rever envio individual</h4>
    <p><strong><?= count($preview['recipients']) ?> destinatário(s) por enviar</strong>. <?= (int)$preview['ignored'] ?> contacto(s) inválido(s), repetido(s) ou com tentativa anterior excluído(s).</p>
    <p>O envio é feito em lotes de até 20 mensagens. Após cada lote, pode continuar até concluir todos os destinatários.</p>
    <div class="table-responsive" style="max-height:420px"><table class="table table-sm align-middle">
        <thead><tr><th>Nome</th><th>Destinatário</th><th>Mensagem personalizada</th></tr></thead>
        <tbody><?php foreach ($preview['recipients'] as $recipient): ?><tr>
            <td><?= $esc($recipient['name']) ?></td><td><?= $esc($recipient['destination']) ?></td>
            <td><strong><?= $esc($recipient['subject']) ?></strong><br><span style="white-space:pre-wrap"><?= $esc($recipient['body']) ?></span></td>
        </tr><?php endforeach; ?></tbody>
    </table></div>
    <form method="post" action="<?= BASE_URL ?>?controller=reservation&amp;action=reminders" class="mt-3" onsubmit="this.querySelector('button').disabled=true">
        <input type="hidden" name="csrf" value="<?= $esc($csrf) ?>">
        <input type="hidden" name="step" value="send">
        <input type="hidden" name="event_id" value="<?= (int)$preview['event_id'] ?>">
        <input type="hidden" name="plan_token" value="<?= $esc($preview['token']) ?>">
        <button class="btn btn-success">Enviar <?= min(20, count($preview['recipients'])) ?> lembrete(s) individualmente</button>
    </form>
</div></div>
<?php endif; ?>
<?php if ($history): ?>
<div class="card shadow-sm"><div class="card-body"><h4>Histórico deste evento</h4>
<p class="text-muted">Cada contacto só recebe uma tentativa de lembrete por canal e evento. Falhas e tentativas interrompidas não são repetidas automaticamente, para evitar duplicações.</p>
<div class="table-responsive"><table class="table table-sm"><thead><tr><th>Contacto</th><th>Canal</th><th>Estado</th><th>Data (UTC)</th></tr></thead><tbody>
<?php $labels = ['accepted' => 'Aceite pelo servidor', 'failed' => 'Falha de envio', 'processing' => 'Em processamento / resultado por confirmar']; ?>
<?php foreach ($history as $entry): ?><tr><td><?= $esc($entry['destination']) ?></td><td><?= $esc($entry['channel']) ?></td><td><?= $esc($labels[$entry['status']] ?? $entry['status']) ?></td><td><?= $esc($entry['updated_at']) ?></td></tr><?php endforeach; ?>
</tbody></table></div></div></div>
<?php endif; ?>
